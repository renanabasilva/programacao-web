#include <iostream>

using namespace std;

int main()
{
    string saudacao="Hello world!";
    for (int i=0;i<5;i++){
    cout << saudacao<<i << endl;
}
    return 0;
}
