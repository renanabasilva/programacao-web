#include<iostream>
using namespace std;

int main(){

    char letra='A';

    while(letra<='Z'){
        cout << letra<<"\t";
        letra++;

    }

}
